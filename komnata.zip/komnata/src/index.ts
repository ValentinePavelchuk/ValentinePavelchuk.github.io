import Swiper, {Navigation} from 'swiper';
import 'swiper/css/bundle';
import './index.scss'

const swiper = new Swiper('.swiper-rooms', {
    modules: [ Navigation ],
    // Optional parameters
    direction: 'horizontal',
    slidesPerView: 'auto',
    centeredSlides: true,
    spaceBetween: 16,
    // Navigation arrows
    navigation: {
        nextEl: '.swiper-rooms-button-next',
        prevEl: '.swiper-rooms-button-prev',
    },
});

const tabButtons = document.querySelectorAll('.rooms-tab-btn');
const tabContent = document.querySelectorAll('.rooms-tab-item');

tabButtons.forEach((button) => {
    button.addEventListener('click', () => {
        const tabNumber = button.getAttribute('data-tab');
        switchTab(tabNumber);
    });
});
function switchTab(tabNumber:string) {
    tabContent.forEach((tab) => {
        tab.classList.remove('active');
    });

    const selectedTab = document.querySelector(`.rooms-tab-item[data-tab="${tabNumber}"]`);

    selectedTab.classList.add('active');

    tabButtons.forEach((button) => {
        button.classList.remove('active');
    });

    const selectedTabButton = document.querySelector(`.rooms-tab-btn[data-tab="${tabNumber}"]`);
    selectedTabButton.classList.add('active');
}