module.exports = {
    syntax: 'postcss-scss',
    plugins: [
        require('autoprefixer')
    ]
}