import './styles/index.scss'

console.log("test")
